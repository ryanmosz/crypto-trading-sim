// Environment configuration for crypto-trading-sim
// This is the production version - only includes frontend-safe values

const ENV = {
  // Your Supabase project URL
  SUPABASE_URL: 'https://yuobwpszomojorrjiwlp.supabase.co',
  
  // Your Supabase anonymous (public) key - safe for frontend
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl1b2J3cHN6b21vam9ycmppd2xwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI5ODI1MDQsImV4cCI6MjA2ODU1ODUwNH0.3ee0zwMXcl4-zlv5sn0gKyJ7BDjtKTVLbL73Qj6eNJs'
  
  // Note: Service role key and API keys should only be used in backend/edge functions
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ENV;
} 

// Also make available in browser
if (typeof window !== 'undefined') {
  window.ENV = ENV;
} 